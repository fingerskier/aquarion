export default function second() {
  console.log('second Fx called')
}